function [Astar,cstar,thetastar] = gen_DCSBM(n,K,pic,Lambda,theta,Type)

%% sampling node community label c
c_mat = mnrnd(1,pic,n);
c=c_mat*(1:K)';

%% smpling edges set A=(A_{ij})_{n*n}
theta_sparseM=sparse(1:n,1:n,theta');
P_A=theta_sparseM*(c_mat*Lambda*c_mat')*theta_sparseM;

switch Type
    case 'binomial'
        A=binornd(ones(n),P_A);  % binomial distribution
    case 'poission'
        A=poissrnd(P_A,n,n);
end

Aup=triu(A,1);
A=Aup+Aup'; 


dA=sum(A);
ind_null0=find(dA~=0);
Astar=sparse(A(ind_null0,ind_null0));
cstar=c(ind_null0);
thetastar=theta(ind_null0);


