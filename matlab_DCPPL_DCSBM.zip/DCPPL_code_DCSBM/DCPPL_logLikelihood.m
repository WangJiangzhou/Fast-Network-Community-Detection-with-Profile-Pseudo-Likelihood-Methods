function [logDCPPL]=DCPPL_logLikelihood(As,c_matrix_old,e_matrix_old,pi_hat_old,theta_old,Lambda_old)

n=size(As,1);
nL=sum(c_matrix_old,1);

V1=nL*log(pi_hat_old+1e-40)';
V2=theta_old*c_matrix_old*Lambda_old*e_matrix_old'*theta_old';


V31=sum(sum(c_matrix_old'*sparse(1:n,1:n,log(theta_old))*As*e_matrix_old));
V32=sum(sum(c_matrix_old'*As*sparse(1:n,1:n,log(theta_old))*e_matrix_old));
V33=sum(sum(log(Lambda_old+1e-40).*(c_matrix_old'*As*e_matrix_old)));

logDCPPL=V1-V2+V31+V32+V33;