function [CPL_logLikelihood,res]=logCPL(Bs, betah, Thetah)

c_matrix=betah;% n-by-K matrix
K=size(c_matrix,2);

Delta=zeros(1,K);
for k=1:K
    Delta(k)=Bs(:,k)'*c_matrix*log(Thetah(:,k)+1e-40);
end

CPL_logLikelihood=-sum(sum(log(factorial(Bs))))+sum(Delta);
res=3;