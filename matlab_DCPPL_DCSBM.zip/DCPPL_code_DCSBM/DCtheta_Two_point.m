function [theta]=DCtheta_Two_point(n,m)

x=2/(m+1);
vals=[m*x x];
theta=datasample(vals, n);