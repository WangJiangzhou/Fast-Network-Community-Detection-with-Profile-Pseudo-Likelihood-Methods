function [ehat,log_likelihood_PPL]=DCPPL_nodeBYnode(As,K,e,T,maxiter_EM)

% maxiter_FPI=20;
% maxiter_EM=50;
% T=20;
n=size(As,1);
dg=sum(As,1);
log_likelihood_PPL=zeros(1,T);

theta_old=n*dg/sum(dg)';
e_matrix_old=sparse(1:n,e,ones(1, n));
c_matrix_old=e_matrix_old;

% h=waitbar(0,'computing...');
for iterT=1:T
    Bs=As*e_matrix_old;   
    for iter_EM=1:maxiter_EM
%         str=['computing...',num2str(100*(maxiter_EM*(iterT-1)+iter_EM)/(T*maxiter_EM)),'%'];waitbar((maxiter_EM*(iterT-1)+iter_EM)/(T*maxiter_EM),h,str);
        % M-step
        pi_hat_old=mean(c_matrix_old);
        a_tild=c_matrix_old'*Bs;
        b_tild=c_matrix_old'*theta_old'*(theta_old*e_matrix_old);
        Lambda_old=a_tild./b_tild;
        
        
%         Astar=c_matrix_old*Lambda_old*e_matrix_old';
%         for s=1:maxiter_FPI
%             theta_old=2*dg./((Astar+Astar')*theta_old')';
%             theta_old=n*theta_old./sum(theta_old);
%         end
        
        for i=1:n
            c_di = -dg(i);
            a_mf = 2*c_matrix_old(i,:)*Lambda_old*e_matrix_old(i,:)';
            
            indx = setdiff(1:n,i);
            deltai = theta_old(indx)*e_matrix_old(indx,:)*Lambda_old';
            b_key = c_matrix_old(i,:)*deltai';
            
            theta_old(i) = (-b_key+sqrt(b_key^2-4*a_mf*c_di))/(2*a_mf);
        end
        theta_old=n*theta_old./sum(theta_old);
        
        b_tild=c_matrix_old'*theta_old'*(theta_old*e_matrix_old);
        Lambda_old=a_tild./b_tild;
        
        
        % E-step
        T1=log(repmat(pi_hat_old,n,1)+1e-40);
        T2=sparse(1:n,1:n,theta_old);
        T3=repmat(theta_old*e_matrix_old*Lambda_old',n,1);
        T4=Bs*log(Lambda_old'+1e-40);
        Z=T1-T2*T3+T4;
        
        Zmax = max(Z')';
        Z = Z - repmat(Zmax,1,K);
        U = exp(Z);
        tau=U./repmat(sum(U,2),1,K); % posterior probability
        c_matrix_old=tau;
    end
    
    %% outer loop
    T2=sparse(1:n,1:n,theta_old);
    T5=repmat(theta_old*c_matrix_old*Lambda_old,n,1);
    Score=-T2*T5+As'*c_matrix_old*log(Lambda_old);
    
    [~,ehat] = max(Score,[],2);
    ehat = ehat(:);
    e_matrix_old=sparse(1:n,ehat,ones(1, n));
%     log_likelihood_PPL(iterT)=DCPPL_logLikelihood(As,c_matrix_old,e_matrix_old,pi_hat_old,theta_old,Lambda_old);
    %compErr(c,ehat)
end
% close(h)  