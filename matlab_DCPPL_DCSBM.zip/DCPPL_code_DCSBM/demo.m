clear;clc;

% parameter setting
n=1200;
K=3;
pic=[0.2 0.3 0.5];
Lambda=1*1e-2.*(1*ones(K)+diag([2,3,4]));
m=4; % DCSBM; note that m=1 corresponds to SBM
[theta]=DCtheta_Two_point(n,m); % sampling degree-corrected parametr theta


% generate the network from DCSBM and remove the isolated nodes  
[As,c,theta]=gen_DCSBM(n,K,pic,Lambda,theta,'binomial');
n=size(As,1); % n maybe less than 1200, since the isolated nodes have been removed


% scp method
compErr = @(c,e) compMuI(compCM(c,e,K));    % use mutual info as a measure of error/sim.
init_opts = struct('verbose',false);
tic, fprintf('%-40s','Applying init. method (SCP) ...')
[e, init_dT] = initLabel5b(As, K, 'scp', init_opts);
RT_scp=toc;
fprintf('%3.5fs\n',RT_scp)
NMI_scp = compErr(c, e);

% CPL method
T = 20;
tic, fprintf('%-40s','Applying CPL ...')
cpl_opts = struct('verbose',false,'delta_max',0.000000001,'itr_num',T,'em_max',500,'track_err',true);
[chat, ~, cpl_dT, post,log_CPL] = cpl4c(As, K, e, c, 'cpl', cpl_opts);
RT_cpl=toc;
fprintf('%3.5fs\n',RT_cpl)
NMI_cpl = compErr(c, chat);

% DCPPL method
T=20;
maxiter_EM=50;
% maxiter_FPI=30;
tic, fprintf('%-40s','Applying DC-PPL ...')
% [chat,log_likelihood_PPL]=DCPPL(As,K,e,T,maxiter_EM,maxiter_FPI); % This step takes about 400 seconds
[chat,log_likelihood_PPL]=DCPPL_nodeBYnode(As,K,e,T,maxiter_EM);
RT_dcppl=toc;
fprintf('%3.5fs\n',RT_dcppl)
NMI_dcppl=compErr(c,chat);

% print the results
fprintf(1,'\nSCP_NMI = %3.2f\nCPL_NMI = %3.2f\n DC-PPL_NMI = %3.2f\n',NMI_scp,NMI_cpl,NMI_dcppl);
fprintf(1,'\nSCP_time = %3.2f\nCPL_time = %3.2f\n DC-PPL_time = %3.2f\n',RT_scp,RT_cpl,RT_dcppl);


