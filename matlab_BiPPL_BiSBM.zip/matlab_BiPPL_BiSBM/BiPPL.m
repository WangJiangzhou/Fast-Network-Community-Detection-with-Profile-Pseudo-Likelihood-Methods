function [chat1,chat2,dT] = BiPPL(As,K1,e1,K2,e2,cpl_opts)
% apply the bipartite profile-pseudo likelihood method to As

[chat1,dT2,~] = oneSide_BiPPL(As',K2,e2,K1,e1,cpl_opts);
[chat2,dT1,~] = oneSide_BiPPL(As,K1,e1,K2,e2,cpl_opts);
dT=dT1+dT2;

end
