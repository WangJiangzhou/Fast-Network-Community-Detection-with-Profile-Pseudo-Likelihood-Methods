clear;clc;

% paprameter setting of the dense case
m=1200;
pri1=[1/2 1/2];
K1=size(pri1,2);

n=1600;
pri2=[1/2 1/2];
K2=size(pri2,2);

P=[0.16 0.12; 0.12 0.16];


% generate data from BiSBM and remove 0-degree nodes
compErr = @(c,e,K) compMuI(compCM(c,e,K));    % use mutual info as a measure of error/sim.
[As, c1, c2]=genBiSBM(m,K1,pri1,n,K2,pri2,P);



% options for the init method
init_opts = struct('verbose',false);
tic, fprintf('%-40s','Applying init. method (SCP) ...')
% use spectral clustering with pertubation to initialize labels
[e1, ~] = initLabel5b(As*As', K1, 'scp', init_opts);
[e2, ~] = initLabel5b(As'*As, K2, 'scp', init_opts);
fprintf('%3.5fs\n',toc);
RT_scp=toc;
init_nmi1 = compErr(c1, e1,K1);NMI_scp1=init_nmi1;
init_nmi2 = compErr(c2, e2,K2);NMI_scp2=init_nmi2;


% apply bi-ppl with init vector "e1" and "e2"
T=20;
cpl_opts = struct('verbose',false,'delta_max',0.000000001, ...
    'itr_num',T,'em_max',500,'track_err',false);
tic, fprintf('%-40s','Applying biPPL method ...')
[chat1,chat2,~] = BiPPL(As,K1,e1,K2,e2,cpl_opts);
fprintf('%3.5fs\n',toc);
RT_bippl=toc;
bippl_nmi1 = compErr(c1, chat1,K1);NMI_bippl1=bippl_nmi1;
bippl_nmi2 = compErr(c2, chat2,K1);NMI_bippl2=bippl_nmi2;


% print the results
fprintf(1,'\nSCP_NMI_side1 = %3.2f\nbiPPL_NMI_side1 = %3.2f\n',NMI_scp1,NMI_bippl1);
fprintf(1,'\nSCP_NMI_side2 = %3.2f\nbiPPL_NMI_side2 = %3.2f\n',NMI_scp2,NMI_bippl2);
fprintf(1,'\nSCP_time = %3.2f\n PPL_time = %3.2f\n',RT_scp,RT_bippl);



