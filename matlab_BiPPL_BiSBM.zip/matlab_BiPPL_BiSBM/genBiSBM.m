function [As, c1, c2]=genBiSBM(m,K1,pri1,n,K2,pri2,P)

% sample c1 and c2
[c1,~] = find(mnrnd(1,pri1,m)');
[c2,~] = find(mnrnd(1,pri2,n)');

% sample A
eyeK1=eye(K1);
eyeK2=eye(K2);
E_A=eyeK1(c1,:)*P*eyeK2(c2,:)';
As=binornd(1,E_A);
if issparse(As)==0
    As=sparse(As); %  converts a full matrix A into sparse
end
% remove 0-degree nodes
zdNodes1 = sum(As,2) == 0;
zdNodes2 = sum(As,1) == 0;
As=As(~zdNodes1,~zdNodes2);
c1=c1(~zdNodes1);
c2=c2(~zdNodes2);


end