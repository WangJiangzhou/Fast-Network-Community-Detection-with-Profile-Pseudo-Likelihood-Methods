function [c_hat, z_hat] = cpl4c_backup(As,K1,K2,c_hat,z_hat,T,type)  

m=size(As,1);n=size(As,2);
eye_K1=eye(K1);eye_K2=eye(K2);
switch lower(type) 
    case 'cc'
        for t = 2:(T+1)
            c_matrix=sparse(eye_K1(c_hat,:));z_matrix=sparse(eye_K2(z_hat,:));
            P_hat=c_matrix.'*As*z_matrix./(sum(c_matrix,1).'*sum(z_matrix,1));
            n_K=sum(z_matrix,1);
            Bs=As*z_matrix;
            a=Bs*log(P_hat.'+1e-30)+(repmat(n_K,m,1)-Bs)*log(1-P_hat.');
            [~,c_hat]=max(a,[],2);
            c_matrix=sparse(eye_K1(c_hat,:));
            
            n_K_col=sum(c_matrix,1);
            B_col=As.'*c_matrix;
            a=B_col*log(P_hat)+(repmat(n_K_col,n,1)-B_col)*log(1-P_hat);
            [~,z_hat]=max(a,[],2);         
        end
    case 'cccc'
         for t = 2:(T+1)
            c_matrix=sparse(eye_K1(c_hat,:));z_matrix=sparse(eye_K2(z_hat,:));
            for i=1:10
                P_hat=c_matrix.'*As*z_matrix./(sum(c_matrix,1).'*sum(z_matrix,1));
                n_K=sum(z_matrix,1);
                Bs=As*z_matrix;
                a=Bs*log(P_hat.'+1e-30)+(repmat(n_K,m,1)-Bs)*log(1-P_hat.');
                [~,c_hat]=max(a,[],2);
                c_matrix=sparse(eye_K1(c_hat,:));
            end
            
            for i=1:10
                P_hat=c_matrix.'*As*z_matrix./(sum(c_matrix,1).'*sum(z_matrix,1));
                n_K_col=sum(c_matrix,1);
                B_col=As.'*c_matrix;
                a=B_col*log(P_hat)+(repmat(n_K_col,n,1)-B_col)*log(1-P_hat);
                [~,z_hat]=max(a,[],2);
                z_matrix=sparse(eye_K2(z_hat,:));
            end
         end
    case 'mm'
        c_matrix=sparse(eye_K1(c_hat,:));z_matrix=sparse(eye_K2(z_hat,:));
        pi_hat=mean(c_matrix,1); 
        P_hat=c_matrix.'*As*z_matrix./(sum(c_matrix,1).'*sum(z_matrix,1));
        pi_hat_star=mean(z_matrix,1);
        for t=2:(T+1)
            n_K=sum(z_matrix,1);                
            Bs=As*z_matrix;
            for t_EM=1:80
                a=Bs*log(P_hat.'+1e-30)+(repmat(n_K,m,1)-Bs)*log(1-P_hat.')+repmat(log(pi_hat),m,1);
                [a_max,~]=max(a,[],2);
                a=a-repmat(a_max,1,K1);
                a=exp(a);
                c_matrix=a./repmat(sum(a,2),1,K1);
                pi_hat=mean(c_matrix,1);
                P_hat=c_matrix.'*As*z_matrix./(sum(c_matrix,1).'*sum(z_matrix,1));   
            end
            
            for i=1:80
                n_K_col=sum(c_matrix,1);
                B_col=As.'*c_matrix;
                a=B_col*log(P_hat)+(repmat(n_K_col,n,1)-B_col)*log(1-P_hat)+repmat(pi_hat_star,n,1);
                [a_max,~]=max(a,[],2);
                a=a-repmat(a_max,1,K1);
                a=exp(a);
                z_matrix=a./repmat(sum(a,2),1,K1);
                pi_hat_star=mean(z_matrix,1);
                P_hat=c_matrix.'*As*z_matrix./(sum(c_matrix,1).'*sum(z_matrix,1));            
            end
        end
        [~,c_hat]=max(c_matrix,[],2);
        [~,z_hat]=max(z_matrix,[],2);
end