function Bs = compBlkCmprss(As,e,K)
% Compute block compression
%
% As  sparse adj. matrix
% e   labeling to use
% K   number of communities

n = size(As,1);

[~, I] = sort(e);
Bs = spalloc(n,K,nnz(As));
for k = 1:K
   Bs(:,k) = sum(As(:,I(e(I) == k)),2);
end
%Ds = sum(Bs,2)

end