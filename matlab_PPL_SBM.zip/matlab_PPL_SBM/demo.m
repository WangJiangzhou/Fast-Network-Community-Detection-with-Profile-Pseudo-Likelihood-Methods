clear;clc;

% % paprameter setting of the dense case
% n=600;
% K=2;
% pi=1/K*ones(1,K);
% P_in=0.9; P_bt=0.84;
% P=P_bt*ones(K,K)+(P_in-P_bt)*eye(K);


% paprameter setting of the sparse case
n=10000;
K=3;
pi=[0.2 0.3 0.5];
P_in=0.0012; P_bt=0.0001;
P=P_bt*ones(K,K)+(P_in-P_bt)*eye(K);




% generate data from SBM
compErr = @(c,e) compMuI(compCM(c,e,K));    % use mutual info as a measure of error/sim.
mo = dcBlkMod4(n,K,P,pi); % create a base SBM model
mo = mo.genData;        % generate data (Adj. matrix "As" and the labels "c")
mo = mo.removeZeroDeg;  % remove zero degree nodes


% options for the init method and upl/ppl
init_opts = struct('verbose',false);
T = 20;
cpl_opts = struct('verbose',false,'delta_max',0.000000001, ...
    'itr_num',T,'em_max',500,'track_err',false);

tic%, fprintf('%-40s','Applying init. method (SCP) ...')
% use spectral clustering with pertubation to initialize labels
[e, init_dT] = initLabel5b(mo.As, mo.K, 'scp', init_opts);
%fprintf('%3.5fs\n',toc);
RT_scp=toc;
init_nmi = compErr(mo.c, e);NMI_scp=init_nmi;



c_hat_initial=e;
% apply upl with init vector "e"
tic %, fprintf('%-40s','Applying UPL ...')
[chat, ~, upl_dT, post] = ...
    cpl4c(mo.As, mo.K,c_hat_initial, mo.c, 'upl', cpl_opts);
%fprintf('%3.5fs\n',toc);
RT_upl=toc;
upl_nmi = compErr(mo.c, chat);NMI_upl=upl_nmi;

% apply ppl with init vector "e"
tic %, fprintf('%-40s','Applying PPL ...')
[chat, ppl_dT,Score]=PPL(mo.As, mo.K, c_hat_initial, cpl_opts);
%fprintf('%3.5fs\n',toc);
RT_ppl=toc;
ppl_nmi = compErr(mo.c, chat);NMI_ppl=ppl_nmi;


% print the results
fprintf(1,'\nSCP_NMI = %3.2f\nUPL_NMI = %3.2f\n PPL_NMI = %3.2f\n',NMI_scp,NMI_upl,NMI_ppl);
fprintf(1,'\nSCP_time = %3.2f\nUPL_time = %3.2f\n PPL_time = %3.2f\n',RT_scp,RT_upl,RT_ppl);



