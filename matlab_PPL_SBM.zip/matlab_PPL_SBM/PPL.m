function [chatF,dT,Score] = PPL(As,K,e,varargin)
% compute profile-pseudo likelihood estimate
% As  sparse Adjacency matrix
% e   the initial labeling
% T   number of iterations on top of EM

%[As,K,e,type,varargin]=[mo.As, mo.K, e, 'ppl', cpl_opts]

options = struct('verbose',false,'verb_level',1,'conv_crit','ppl', ...
    'em_max',100,'delta_max',0,'itr_num',20,'track_err',true); %default options
if nargin > 5
    % process options
    optNames = fieldnames(options);
    passedOpt = varargin{end};
  
    if ~isstruct(passedOpt), 
        error('Last argument should be an options struct.')
    end
    for fi = reshape(fieldnames(passedOpt),1,[])
        if any(strmatch(fi,optNames))
            options.(fi{:}) = passedOpt.(fi{:});
        else
            error('Unrecognized option name: %s', fi{:})
        end
    end
end


rowSumNZ = @(X) X./repmat(sum(X,2),1,size(X,2)); % normalize row sum to 1
% swap= @(varargin) varargin{nargin:-1:1};         % swap two variables
epsilon = 1e-3;
regularize = @(x) (x+epsilon).*(x == 0) + x.*(x ~= 0);

LOG_REAL_MAX = log(realmax)-1;

T = options.itr_num;

% remove 0-degree nodes
zdNodes = sum(As,2) == 0;
nOrg = size(As,1);
% zdNum = nnz(zdIDX);
% AsOrg = As;
% eOrg = e;

As = As(~zdNodes,~zdNodes);
e = e(~zdNodes);
n = size(As,1);


% Compute initial Phat
Phat = zeros(K);
for k = 1:K
    for ell = 1:K
        Phat(k,ell) = mean( reshape( As( e == k, e == ell ), [], 1) );
        
        Phat(k,ell) = regularize( Phat(k,ell) );
    end
end


% Compute initial Rhat
Rhat = zeros(K);
for k = 1:K
    Rhat(k,k) = sum( e == k ) / n;    
    Rhat(k,k) = regularize( Rhat(k,k) );    
end


% Compute inital community prior estimates
pih = diag(Rhat);
%pih = rand(K,1); pih = pih/sum(pih);



emN = options.em_max;           % max. EM steps
%deltaMax = 2/n;
if options.delta_max == 0
    switch options.conv_crit
        case 'param'
            deltaMax = 1e-3; % max. error below which EM terminates
        case 'label'
            deltaMax = 1e-2;    
        case 'ppl'
            deltaMax = 1e-2;    
    end
else
    deltaMax = options.delta_max;
end
% initial chat
chat = e;
% chatOld = chat;


% Compute block compressions
Bs = compBlkCmprss(As,e,K);

if options.verbose
    fprintf(1,'\nupm: %3d iterations\n',T)
end

tic
Iter=zeros(1,T+1);
Iter(1)=100;
for t = 2:(T+1)
    n_K=ones(1,K);
    for k=1:K
        n_K(k)=sum(chat==k);
    end
    
    delVec = zeros(emN,1);
    OVF_FLAG = false;
    
    delta = inf;
    nu = 1;
    CONVERGED = false;
    while (nu <= emN) && (~CONVERGED) %(delta > deltaMax)
        % Z is K x n
        Z = Bs * log(Phat+1e-30)'+ (repmat(n_K,n,1)-Bs)*log(1-Phat+1e-30)'+repmat(log(pih'+1e-30),n,1);
        [maxZ,~]=max(Z,[],2);
        Z=Z-repmat(maxZ,1,K);
        [ZZ, OVF] = handleOverflow(Z,LOG_REAL_MAX);
        U = exp( ZZ );
        if OVF
            OVF_FLAG = true;
        end
        alpha=U./(repmat(sum(U,2),1,K)+1e-30);
        
        
        
        
        plVal=sum(sum((alpha'*Bs).*log(Phat+1e-30)))+...
            sum(sum(alpha'*(repmat(n_K,n,1)-Bs).*log(1-Phat+1e-30)))+sum(alpha,1)*log(pih+1e-30);
        %plVal = sum( log(post_denom) );
        
        % alpha is n x K -- This is posterior prob. of labels
        % Bs is n x K
        
        if any(isnan(alpha(:)))
            error('Something went wrong, pih will havve NaN entries.')
        end
        
        
        
        pih = mean(alpha,1)';
        
        Phat=(alpha'*Bs)./(sum(alpha,1)'*n_K+1e-30);
        
        if nu ~= 1
            delta = abs((plVal - plValOld)/plValOld);
            CONVERGED = delta < deltaMax;
            delVec(nu-1) = delta;
        end
        plValOld = plVal;
        
        if options.verbose && (options.verb_level > 1)
            print_pl_decay(nu,delta,CONVERGED)
        end
        
        nu = nu + 1;
    end % end while
    
    n_v=sum(alpha,1);
    B_star=As'*alpha;
    Score=B_star*log(Phat+1e-30)+(repmat(n_v,n,1)-B_star)*log(1-Phat+1e-30);
    [~,chat] = max(Score,[],2);
    chat = chat(:);
    
    Bs = compBlkCmprss(As,chat,K);
    
    Iter(t)=nu;
    if Iter(t-1)==3
        break
    end
end
chatF = zeros(nOrg,1);
chatF(~zdNodes) = chat;

pihh = zeros(1,K);
for k = 1:K
    pihh(1,k) = sum( chat == k ) / n;
end
[~,chat_zd] = max(mnrnd(1,pihh, nnz(zdNodes)),[],2);
chat_zd = chat_zd(:);
chatF(zdNodes) = chat_zd;
dT = toc;
end

function Bs = compBlkCmprss(As,e,K)
% Compute block compression
%
% As  sparse adj. matrix
% e   labeling to use
% K   number of communities

n = size(As,1);

[~, I] = sort(e);
Bs = spalloc(n,K,nnz(As));
for k = 1:K
   Bs(:,k) = sum(As(:,I(e(I) == k)),2);
end
%Ds = sum(Bs,2)

end

function Bs = softcompBlkCmprss(As,e,~)
% Compute block compression
%
% As  sparse adj. matrix
% e   labeling posterior probability to use n by K
% K   number of communities
Bs=As*e;
end

function [ZZ,OVF] = handleOverflow(Z,LOG_MAX)
    Zmax = max(abs(Z(:)));
   
    if Zmax > LOG_MAX
        ZZ = (LOG_MAX / Zmax) * Z;
        OVF = true;
    else
        ZZ = Z;
        OVF = false;
    end
end

function print_pl_decay(nu,delta,CONVERGED)
    if nu == 1
        fprintf(1,'    .... ')
    else
        fprintf(1,'%3.5f ',delta)
        if (mod(nu,5) == 0) || CONVERGED 
            fprintf(1,'\n    .... ');
        end
    end
end