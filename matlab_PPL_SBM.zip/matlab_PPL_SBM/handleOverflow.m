function [ZZ,OVF] = handleOverflow(Z,LOG_MAX)
    Zmax = max(abs(Z(:)));
   
    if Zmax > LOG_MAX
        ZZ = (LOG_MAX / Zmax) * Z;
        OVF = true;
    else
        ZZ = Z;
        OVF = false;
    end
end